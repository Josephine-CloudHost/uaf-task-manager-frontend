/*************************************************************
 * CONFIG
 * -----------------------------------------------------------
 * Paste your Apps Script Web App URL below (Deploy > New
 * deployment > Web app > copy the URL ending in /exec).
 * That's the only edit required to make this front end work.
 *************************************************************/
const CONFIG = {
  API_URL: 'PASTE_YOUR_APPS_SCRIPT_EXEC_URL_HERE',
  ORG_NAME: 'UAF-LR',
  APP_NAME: 'Field Ledger',
};
